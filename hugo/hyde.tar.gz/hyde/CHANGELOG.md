# Changelog

## Version 1.0

- Due to the switch to the base template feature the minimum required version of Hugo changed to v0.21
- Support for Google Analytics have been added
- Hugo's internal Disqus template replaced the custom one of this theme. The Disqus shortname now has to be defined outsite the `[params]` blog
